![](https://raw.githubusercontent.com/Matthewpco/WP-Plugin-Housing-Calculator/main/Housing-calculator-page.png)

# WordPress plugin to calculate housing costs based on various incomes and percentages.

<br>

## 🙋‍♂️ Introduction

- This plugin creates a shortcode and menu in the dashboard witha  form to input your income select the income type and preferred percentage to calulate your housing cost per month. Generally around 30% of your gross income should be speant on housing.

<br>

## 📜 Features

- HTML
- CSS
- PHP
- WordPress Plugin


  <br>
  
![](https://raw.githubusercontent.com/Matthewpco/WP-Plugin-Housing-Calculator/main/Housing-calculator-dashboard.png)
